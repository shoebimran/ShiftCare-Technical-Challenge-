Rails.application.routes.draw do
  # Define your application routes per the DSL in https://guides.rubyonrails.org/routing.html

  # Defines the root path route ("/")
  # root "articles#index"
  get '/clients', to: 'clients#index'
  # get '/clients/search', to: 'clients#search'
  get '/client/find_duplicates', to: 'clients#find_duplicates', as: 'find_duplicates' # Corrected controller name

  get '/v1/clients', to: 'v1/data_items#index'
  post '/v1/create', to: 'v1/data_items#create'


end
