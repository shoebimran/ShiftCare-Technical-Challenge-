class V1::DataItemsController < ApplicationController
  def new
    @data_item = DataItem.new
  end

  def create
    if data_item_params[:json_file].present?
      store_uploaded_json_file
      redirect_to  notice: 'JSON file uploaded successfully.'
    else
      render :new
    end
  end

  private

  def data_item_params
    params.permit(:json_file)
  end

  def store_uploaded_json_file
    uploaded_io = data_item_params[:json_file]
    if uploaded_io.present?
      file_path = Rails.root.join('public', 'data.json')    
      File.open(file_path, 'wb') do |file|
        file.write(uploaded_io.read)
      end
      p file_path.to_s 
      file_path.to_s
    end
  end
end
