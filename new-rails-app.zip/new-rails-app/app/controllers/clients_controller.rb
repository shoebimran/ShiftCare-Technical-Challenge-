class ClientsController < ApplicationController
  before_action :load_clients

  def index
    respond_to do |format|
      format.html
      format.json { render json: @clients }
    end
  end

  def find_duplicates
    email_counts = Hash.new(0)
    duplicate_clients = Set.new

    @clients.each do |client|
      email = client['email']
      if email_counts[email] > 0
        duplicate_clients.add(client)
      end
      email_counts[email] += 1
    end

    respond_to do |format|
      if duplicate_clients.present?
        format.html { render 'duplicates', locals: { duplicates: duplicate_clients.to_a } }
        format.json { render json: duplicate_clients.to_a }
      else
        flash[:notice] = "No duplicate email addresses found."
        format.html { redirect_to action: :index }
        format.json { render json: flash[:notice] }
      end
    end
  end

  private

  def load_clients
    begin
      file_path = Rails.root.join('public', 'data.json')
      @clients = JSON.parse(File.read(file_path))
      
      if params[:search].present?
        search_query = params[:search].downcase
        @clients = filter_clients_by_query(@clients, search_query)
      end
    rescue StandardError => e
      render json: { error: "Error loading JSON file: #{e.message}" }, status: :bad_request
    end
  end

  def filter_clients_by_query(clients, query)
    clients.select do |client|
      client['full_name'].downcase.include?(query) ||
        client['email'].downcase.include?(query) ||
        client['id'].to_s.include?(query)
    end.uniq { |client| client['id'] }
  end
end
